package com.web;

import com.dao.CustomerDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CustomerDeleteServlet")
public class CustomerDeleteServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static CustomerDAO customerDAO = new CustomerDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("customerId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String customerId = request.getParameter("customerId");
        try {
            if (customerDAO.deleteCustomer(customerId)) {
                
                response.sendRedirect("login.jsp");
            } else {
                request.setAttribute("errorMessage", "Account deletion failed.");
                request.getRequestDispatcher("customer_delete.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("customer_delete.jsp").forward(request, response);
        }
    }
}
