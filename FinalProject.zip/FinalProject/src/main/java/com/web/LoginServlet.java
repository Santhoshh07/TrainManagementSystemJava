package com.web;


import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.bean.Customer;
import com.dao.CustomerDAO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static CustomerDAO customerManager = new CustomerDAO();

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("username");
        String password = request.getParameter("password"); // Assume hashed password validation in future updates //
                                                            // Input validation
        if (email == null || password == null || email.isEmpty() || password.isEmpty()) {
            request.setAttribute("errorMessage", "Email and Password are required.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }
        try {System.out.println(email);
        
        if(email.equals("admin")&&password.equals("admin@12345") )
        {
        	 RequestDispatcher dispatcher = request.getRequestDispatcher("admin.jsp"); dispatcher.forward(request, response); 
        }
        
            Customer customer = customerManager.getCustomerByEmail(email);
            if (customer != null && customer.getPassword().equals(password)) { // Assuming password validation logic (implement secure hashing/encryption
                                    // later)
            
                HttpSession session = request.getSession();
                session.setAttribute("customerId", customer.getEmail());
                session.setAttribute("customerName", customer.getCustomerName());
                response.sendRedirect("customer_dashboard.jsp");
            } else {
                request.setAttribute("errorMessage", "Invalid email or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}