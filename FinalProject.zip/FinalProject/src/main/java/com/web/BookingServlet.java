package com.web;
import java.util.Random;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.bean.Ticket;
import com.dao.BookingDAO;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static BookingDAO bookingDAO = new BookingDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {PrintWriter pw=response.getWriter();
            HttpSession session = request.getSession();
            response.setContentType("text/html");
            String action =request.getParameter("action");
    		System.out.print(action);
        	if("BookTicket".equals(action)) {
        // Retrieve ticket details from form
        Random r=new Random();
        String ticketId = "BKID"+r.nextInt(100000);
        String trainNumber = request.getParameter("trainNumber");
        String startLocation = request.getParameter("startLocation");
        String destination = request.getParameter("destination");
        String pid=  (String)session.getAttribute("customerId");
        String status = "Booked"; // Default status
        String departureTime = request.getParameter("departureTime");
        String arrivalTime = request.getParameter("arrivalTime");
        String noseats =  request.getParameter("noseats");
        double	price = Double.parseDouble(request.getParameter("price")); // Create ticket object
        Ticket ticket = new Ticket(ticketId, trainNumber,pid, startLocation, destination, status,
                departureTime, arrivalTime, noseats, Integer.parseInt(noseats)*price); // Attempt to book ticket
        
        try {
            if (bookingDAO.bookTicket(ticket)) { 
            	pw.print("<h4 align='center' style='color:green;'>Ticket ID - "+ticketId+" booked succesfully with seat nos: ");
         for(int i=0;i<Integer.parseInt(noseats);i++)
            		{pw.println(r.nextInt(100));}
            	pw.print("!!</h4>"
            			+ "<a href='customer_dashboard.jsp'>Go back to Dashboard</a>");
    		}else {
    			pw.print("<h4 align='center' style='color:red;'>Product Registration Failed!</h4>");
    		}
            	
          
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("booking.jsp").forward(request, response);
        }
    }
}
}
