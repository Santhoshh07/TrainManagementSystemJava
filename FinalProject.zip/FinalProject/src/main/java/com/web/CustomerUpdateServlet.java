package com.web;

import com.dao.CustomerDAO;
import com.bean.Customer;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CustomerUpdateServlet")
public class CustomerUpdateServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static CustomerDAO customerDAO = new CustomerDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("customerId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String customerId = request.getParameter("customerId");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String password = request.getParameter("password");
        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("customer_update.jsp").forward(request, response);
            return;
        }
        if (!email.matches("^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")) {
            request.setAttribute("errorMessage", "Invalid email format.");
            request.getRequestDispatcher("customer_update.jsp").forward(request, response);
            return;
        }
        if (!phone.matches("^[0-9]{10}$")) {
            request.setAttribute("errorMessage", "Phone number must be exactly 10 numeric digits.");
            request.getRequestDispatcher("customer_update.jsp").forward(request, response);
            return;
        }
        Customer customer = new Customer(customerId, name, email, phone, address,password);
        try {
            if (customerDAO.updateCustomer(customer)) {
                response.sendRedirect("customer_dashboard.jsp");
            } else {
                request.setAttribute("errorMessage", "Customer update failed.");
                request.getRequestDispatcher("customer_update.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("customer_update.jsp").forward(request, response);
        }
    }
}
