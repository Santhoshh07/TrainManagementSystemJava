package com.web;

import com.dao.TrainDAO;
import com.bean.Train;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminTrainUpdateServlet")
public class AdminTrainUpdateServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static TrainDAO trainDAO = new TrainDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve train details from form submission
    	response.setContentType("text/html");
		String action =request.getParameter("action");
		System.out.print(action);
    	if("UpdateTrain".equals(action)) {
    	
    	
    	String trainNumber = request.getParameter("trainNumber");
        String trainName = request.getParameter("trainName");
        String trainCategory = request.getParameter("trainCategory");
        String departureStation = request.getParameter("departureStation");
        String arrivalStation = request.getParameter("arrivalStation");
        String departureTime = request.getParameter("departureTime");
        String arrivalTime = request.getParameter("arrivalTime");
        double speed = Double.parseDouble(request.getParameter("speed"));
        int numberOfStops = Integer.parseInt(request.getParameter("numberOfStops"));
        double fare = Double.parseDouble(request.getParameter("fare"));
        String premiumServices = request.getParameter("premiumServices");

        // Validate input fields
        if (trainNumber.isEmpty() || trainName.isEmpty() || trainCategory.isEmpty() || departureStation.isEmpty()
            || arrivalStation.isEmpty() || departureTime.isEmpty() || arrivalTime.isEmpty() || premiumServices.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("admin_train_update.jsp").forward(request, response);
            return;
        }

        // Create train object
        Train train = new Train(trainNumber, trainName, trainCategory, departureStation, arrivalStation,
                                departureTime, arrivalTime, speed, numberOfStops, fare, premiumServices);

        // Attempt to update train details
        try {
            if (trainDAO.updateTrain(train)) {
                response.sendRedirect("admin.jsp"); // Redirect to admin dashboard after successful update
            } else {
                request.setAttribute("errorMessage", "Train update failed.");
                request.getRequestDispatcher("admin_train_update.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("admin_train_update.jsp").forward(request, response);
        }
    }
}}