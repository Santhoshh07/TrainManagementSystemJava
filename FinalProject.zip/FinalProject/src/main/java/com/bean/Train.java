package com.bean;

public class Train {
    private String trainNumber;
    private String trainName;
    private String trainCategory;
    private String departureStation;
    private String arrivalStation;
    private String departureTime;
    private String arrivalTime;
    private double speed;
    private int numberOfStops;
    private double fare;
    private String premiumServices;
   

    public Train(String trainNumber, String trainName, String trainCategory, String departureStation,
            String arrivalStation, String departureTime, String arrivalTime,double speed, int numberOfStops,
            double fare,String premiumServices) {
        this.trainNumber = trainNumber;
        this.trainName = trainName;
        this.trainCategory = trainCategory;
        this.departureStation = departureStation;
        this.arrivalStation = arrivalStation;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.speed=speed;
        this.numberOfStops = numberOfStops;
        this.fare = fare;
        this.premiumServices=premiumServices;
    } // Getters

    public String getTrainNumber() {
        return trainNumber;
    }

    public String getTrainName() {
        return trainName;
    }

    public String getTrainCategory() {
        return trainCategory;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public String getArrivalStation() {
        return arrivalStation;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public double getSpeed() {
        return speed;
    }

    public int getNumberOfStops() {
        return numberOfStops;
    }

    public double getFare() {
        return fare;
    }

   
     // Setters

    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public void setTrainCategory(String trainCategory) {
        this.trainCategory = trainCategory;
    }

    public void setDepartureStation(String departureStation) {
        this.departureStation = departureStation;
    }

    public void setArrivalStation(String arrivalStation) {
        this.arrivalStation = arrivalStation;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void setNumberOfStops(int numberOfStops) {
        this.numberOfStops = numberOfStops;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

   // Display Train Details

    public void displayTrainDetails() {
        System.out.println("Train Number: " + trainNumber);
        System.out.println("Train Name: " + trainName);
        System.out.println("Category: " + trainCategory);
        System.out.println("From: " + departureStation + " To: " + arrivalStation);
        System.out.println("Departure Time: " + departureTime + ", Arrival Time: " + arrivalTime);
        System.out.println("Speed: " + speed + " km/h, Stops: " + numberOfStops);
        System.out.println("Fare: " + fare);
    
    }

	public String getPremiumServices() {
		return premiumServices;
	}

	public void setPremiumServices(String premiumServices) {
		this.premiumServices = premiumServices;
	}
}