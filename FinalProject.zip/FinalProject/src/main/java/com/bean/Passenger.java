package com.bean;

public class Passenger {
    private String passengerId;
    private String passengerName;
    private String email;
    private int age;
    private String contactNumber;
    private String gender;

    public Passenger(String passengerId, String passengerName, String email, int age, String contactNumber,
            String gender) {
        this.passengerId = passengerId;
        this.passengerName = passengerName;
        this.email = email;
        this.age = age;
        this.contactNumber = contactNumber;
        this.gender = gender;
    } // Getters

    public String getPassengerId() {
        return passengerId;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public String getEmail() {
        return email;
    }

    public int getAge() {
        return age;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return "PassengerId: " + passengerId + ", Name: " + passengerName + ", Email: " + email + ", Age: " + age
                + ", Contact: " + contactNumber + ", Gender: " + gender;
    }
}
