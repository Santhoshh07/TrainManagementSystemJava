package com.bean;

public class Ticket {
    private String ticketId;
    private String trainNumber;
    private String passengerId;
    private String startLocation;
    private String destination;
    private String status;
    private String departureTime;
    private String arrivalTime;
    private String seatNo;
    private double price;

    public Ticket(String ticketId, String trainNumber, String passengerId, String startLocation, String destination,
            String status, String departureTime, String arrivalTime, String seatNo, double price) {
        this.ticketId = ticketId;
        this.trainNumber = trainNumber;
        this.passengerId = passengerId;
        this.startLocation = startLocation;
        this.destination = destination;
        this.status = status;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.seatNo = seatNo;
        this.price = price;
    } // Getters

    public String getTicketId() {
        return ticketId;
    }

    public String getTrainNumber() {
        return trainNumber;
    }

    public String getPassengerId() {
        return passengerId;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public String getDestination() {
        return destination;
    }

    public String getStatus() {
        return status;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public double getPrice() {
        return price;
    } // Setters

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }

    public void setPassengerId(String passengerId) {
        this.passengerId = passengerId;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public void setPrice(double price) {
        this.price = price;
    } // Display Ticket Details

    public void displayTicketDetails() {
        System.out.println("Ticket ID: " + ticketId);
        System.out.println("Train Number: " + trainNumber);
        System.out.println("Passenger ID: " + passengerId);
        System.out.println("From: " + startLocation + " To: " + destination);
        System.out.println("Departure Time: " + departureTime + " Arrival Time: " + arrivalTime);
        System.out.println("Seat No: " + seatNo + ", Price: " + price);
        System.out.println("Status: " + status);
    }
}