package com.bean;

public class Customer {
    private String customerId;
    private String customerName;
    private String email;
    private String address;
    private String contactNumber;
	private String password;

    public Customer(String customerId, String customerName, String email, String address, String contactNumber, String password) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.email = email;
        this.address = address;
        this.contactNumber = contactNumber;
        this.password=password;
    }

    // Getters and setters
    public String getCustomerId() {
        return customerId;
    }

    public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustomerName() {
        return customerName;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    @Override
    public String toString() {
        return "CustomerId: " + customerId + ", Name: " +
                customerName + ", Email: " + email + ", Address: " + address + ", Contact: "
                + contactNumber;
    }
}