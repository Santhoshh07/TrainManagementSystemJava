package com.dao;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import com.bean.Customer;
import com.bean.Train;
import com.helper.Helper;

public class CustomerDAO {
    public boolean addCustomer(Customer customer) throws SQLException {
        String query = "INSERT INTO customers VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, customer.getCustomerId());
            pstmt.setString(2, customer.getCustomerName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getAddress());
            pstmt.setString(5, customer.getContactNumber());
            pstmt.setString(6, customer.getPassword());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updateCustomer(Customer customer) throws SQLException {
        String query = "UPDATE customers SET customer_id=?, name=?,address=?, contact_number=? ,password=? WHERE email=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
             pstmt.setString(1, customer.getCustomerId());
             pstmt.setString(2, customer.getCustomerName());
          
             pstmt.setString(3, customer.getAddress());
             pstmt.setString(4, customer.getContactNumber());
             pstmt.setString(5, customer.getPassword());
             pstmt.setString(6, customer.getEmail());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean deleteCustomer(String email) throws SQLException {
        String query = "DELETE FROM customers WHERE email=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            return pstmt.executeUpdate() > 0;
        }
    }

    public Customer getCustomerByEmail(String email) throws SQLException {
        String query = "SELECT * FROM customers WHERE email=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Customer(rs.getString("customer_id"), rs.getString("name"), rs.getString("email"),
                            rs.getString("address"), rs.getString("contact_number"), rs.getString("password"));
                }
            }
        }
        return null;
    }
    
    public List<Customer> getAllCustomers() throws SQLException {
    	 List<Customer> c = new ArrayList<>();
        String query = "SELECT * FROM customers";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    c.add( new Customer(rs.getString("customer_id"), rs.getString("name"), rs.getString("email"),
                            rs.getString("address"), rs.getString("contact_number"), rs.getString("password")));
                }
            }
        }
        return c;
    }
}