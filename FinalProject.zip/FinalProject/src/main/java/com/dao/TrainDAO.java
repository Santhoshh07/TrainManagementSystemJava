package com.dao;

import com.bean.Train;
import com.helper.Helper;

import java.sql.*;
import java.util.*;

public class TrainDAO {
    public boolean addTrain(Train train) throws SQLException {
        String query = "INSERT INTO trains (train_number, train_name, train_category, departure_station, arrival_station, departure_time, arrival_time, speed, number_of_stops, fare, premium_services) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, train.getTrainNumber());
            pstmt.setString(2, train.getTrainName());
            pstmt.setString(3, train.getTrainCategory());
            pstmt.setString(4, train.getDepartureStation());
            pstmt.setString(5, train.getArrivalStation());
            pstmt.setString(6, train.getDepartureTime());
            pstmt.setString(7, train.getArrivalTime());
            pstmt.setDouble(8, train.getSpeed());
            pstmt.setInt(9, train.getNumberOfStops());
            pstmt.setDouble(10, train.getFare());
            pstmt.setString(11, train.getPremiumServices());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updateTrain(Train train) throws SQLException {
        String query = "UPDATE trains SET train_name=?, train_category=?, departure_station=?, arrival_station=?, departure_time=?, arrival_time=?, speed=?, number_of_stops=?, fare=?, premium_services=? WHERE train_number=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, train.getTrainName());
            pstmt.setString(2, train.getTrainCategory());
            pstmt.setString(3, train.getDepartureStation());
            pstmt.setString(4, train.getArrivalStation());
            pstmt.setString(5, train.getDepartureTime());
            pstmt.setString(6, train.getArrivalTime());
            pstmt.setDouble(7, train.getSpeed());
            pstmt.setInt(8, train.getNumberOfStops());
            pstmt.setDouble(9, train.getFare());
            pstmt.setString(10, train.getPremiumServices());
            pstmt.setString(11, train.getTrainNumber());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean deleteTrain(String trainNumber) throws SQLException {
        String query = "DELETE FROM trains WHERE train_number=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, trainNumber);
            return pstmt.executeUpdate() > 0;
        }
    }

    public Train getTrainByNumber(String trainNumber) throws SQLException {
        String query = "SELECT * FROM trains WHERE train_number=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, trainNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Train(rs.getString("train_number"), rs.getString("train_name"),
                            rs.getString("train_category"), rs.getString("departure_station"),
                            rs.getString("arrival_station"), rs.getString("departure_time"),
                            rs.getString("arrival_time"), rs.getDouble("speed"), rs.getInt("number_of_stops"),
                            rs.getDouble("fare"), rs.getString("premium_services"));
                }
            }
        }
        return null;
    }

    public static List<Train> searchTrains(String source, String destination) throws SQLException {
        List<Train> trainList = new ArrayList<>();
        String query = "SELECT * FROM trains WHERE departure_station=? AND arrival_station=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, source);
            pstmt.setString(2, destination);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    trainList.add(new Train(rs.getString("train_number"), rs.getString("train_name"),
                            rs.getString("train_category"), rs.getString("departure_station"),
                            rs.getString("arrival_station"), rs.getString("departure_time"),
                            rs.getString("arrival_time"), rs.getDouble("speed"), rs.getInt("number_of_stops"),
                            rs.getDouble("fare"), rs.getString("premium_services")));
                }
            }
        }
        return trainList;
    }

    public List<Train> searchTrainsByPrefix(String prefix) throws SQLException {
        List<Train> trainList = new ArrayList<>();
        String query = "SELECT * FROM trains WHERE train_name LIKE ?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, prefix + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    trainList.add(new Train(rs.getString("train_number"), rs.getString("train_name"),
                            rs.getString("train_category"), rs.getString("departure_station"),
                            rs.getString("arrival_station"), rs.getString("departure_time"),
                            rs.getString("arrival_time"), rs.getDouble("speed"), rs.getInt("number_of_stops"),
                            rs.getDouble("fare"), rs.getString("premium_services")));
                }
            }
        }
        return trainList;
    }
    
    public List<Train> allTrains() throws SQLException {
        List<Train> trainList = new ArrayList<>();
        String query = "SELECT * FROM trains";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
         
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    trainList.add(new Train(rs.getString("train_number"), rs.getString("train_name"),
                            rs.getString("train_category"), rs.getString("departure_station"),
                            rs.getString("arrival_station"), rs.getString("departure_time"),
                            rs.getString("arrival_time"), rs.getDouble("speed"), rs.getInt("number_of_stops"),
                            rs.getDouble("fare"), rs.getString("premium_services")));
                }
            }
        }
        return trainList;
    }
}
