package com.dao;


import java.sql.*;


import com.helper.Helper;

public class TicketDAO {
	

	    public boolean cancelTicket(String ticketId) throws SQLException {
	        String query = "DELETE FROM tickets WHERE ticket_id=?";
	        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setString(1, ticketId);
	            return pstmt.executeUpdate() > 0;
	        }
	    }
}
