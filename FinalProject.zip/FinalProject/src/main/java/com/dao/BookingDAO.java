package com.dao;


import java.sql.*;
import java.util.*;

import com.bean.Ticket;
import com.bean.Train;
import com.helper.Helper;

public  class BookingDAO {
    public static List<Ticket> getBookingHistory(String customerId) throws SQLException {
        List<Ticket> tr = new ArrayList<>();
        String query = "SELECT * FROM ticket WHERE pid=?";
      
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, customerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    
                    tr.add(new Ticket( rs.getString(1) ,rs.getString(2),rs.getString(3),rs.getString(4),
                    		rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)
                    		,rs.getString(9),rs.getDouble(10)));
                }
            }
        }
     
		return tr;
    }
    
    public static boolean cancelTicket(String ticketId) throws SQLException {
        String query = "DELETE FROM ticket WHERE tid=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ticketId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    public boolean bookTicket(Ticket ticket) throws SQLException {
        String query = "INSERT INTO ticket VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, ticket.getTicketId());
            pstmt.setString(2, ticket.getTrainNumber());
            pstmt.setString(3, ticket.getPassengerId());
            pstmt.setString(4, ticket.getStartLocation());
            pstmt.setString(5, ticket.getDestination());
            pstmt.setString(6, ticket.getStatus());
            pstmt.setString(7, ticket.getDepartureTime());
            pstmt.setString(8, ticket.getArrivalTime());
            pstmt.setString(9, ticket.getSeatNo());
            pstmt.setDouble(10, ticket.getPrice());
            return pstmt.executeUpdate() > 0;
        }
    }
}

