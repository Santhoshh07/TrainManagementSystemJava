package com.dao;

import java.sql.*;
import com.bean.Passenger;
import com.helper.Helper;

public class PassengerDAO {
    public boolean addPassenger(Passenger passenger) throws SQLException {
        String query = "INSERT INTO passengers (passenger_id, name, email, age, contact_number, gender) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passenger.getPassengerId());
            pstmt.setString(2, passenger.getPassengerName());
            pstmt.setString(3, passenger.getEmail());
            pstmt.setInt(4, passenger.getAge());
            pstmt.setString(5, passenger.getContactNumber());
            pstmt.setString(6, passenger.getGender());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updatePassenger(Passenger passenger) throws SQLException {
        String query = "UPDATE passengers SET name=?, age=?, contact_number=?, gender=? WHERE email=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, passenger.getPassengerName());
            pstmt.setInt(2, passenger.getAge());
            pstmt.setString(3, passenger.getContactNumber());
            pstmt.setString(4, passenger.getGender());
            pstmt.setString(5, passenger.getEmail());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean deletePassenger(String email) throws SQLException {
        String query = "DELETE FROM passengers WHERE email=?";
        try (Connection conn = Helper.CreateConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, email);
            return pstmt.executeUpdate() > 0;
        }
    }
}
