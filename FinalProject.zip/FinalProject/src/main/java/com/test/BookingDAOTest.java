package com.test;

import com.bean.Ticket;
import com.dao.BookingDAO;
import com.helper.Helper;
import org.junit.jupiter.api.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BookingDAOTest {
    private BookingDAO bookingDAO;

    @BeforeAll
    public void setupDatabase() throws Exception {
        bookingDAO = new BookingDAO();
        
    }

    @BeforeEach
    public void clearTickets() throws Exception {
        try (Connection conn = Helper.CreateConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM ticket");
        }
    }

    @Test
    public void testBookTicket() throws Exception {
        Ticket ticket = new Ticket("T001", "TN123", "CUST01", "Station A", "Station B", "Booked", "08:00", "12:00",
                "A1", 500.0);
        boolean result = bookingDAO.bookTicket(ticket);
        assertTrue(result);
    }

    @Test
    public void testGetBookingHistory() throws Exception {
        Ticket ticket1 = new Ticket("T002", "TN124", "CUST02", "City A", "City B", "Booked", "09:00", "13:00", "B1",
                600.0);
        Ticket ticket2 = new Ticket("T003", "TN125", "CUST02", "City C", "City D", "Booked", "10:00", "14:00", "B2",
                700.0);
        bookingDAO.bookTicket(ticket1);
        bookingDAO.bookTicket(ticket2);
        List<Ticket> history = BookingDAO.getBookingHistory("CUST02");
        assertEquals(2, history.size());
    }

    @Test
    public void testCancelTicket() throws Exception {
        Ticket ticket = new Ticket("T004", "TN126", "CUST03", "Loc A", "Loc B", "Booked", "11:00", "15:00", "C1",
                800.0);
        bookingDAO.bookTicket(ticket);
        boolean deleted = BookingDAO.cancelTicket("T004");
        assertTrue(deleted);
        List<Ticket> history = BookingDAO.getBookingHistory("CUST03");
        assertEquals(0, history.size());
    }
}