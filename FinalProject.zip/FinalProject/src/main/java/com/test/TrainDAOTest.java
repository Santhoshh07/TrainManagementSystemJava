package com.test;

import com.bean.Train;
import com.dao.TrainDAO;
import com.helper.Helper;
import org.junit.jupiter.api.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TrainDAOTest {
    private TrainDAO trainDAO;

    @BeforeAll
    public void setupDatabase() throws Exception {
        trainDAO = new TrainDAO();
        
    }

    @BeforeEach
    public void clearTable() throws Exception {
        try (Connection conn = Helper.CreateConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM trains");
        }
    }

    @Test
    public void testAddAndGetTrain() throws Exception {
        Train train = new Train("T100", "Express A", "Express", "City A", "City B", "09:00", "13:00", 120.0, 5, 550.0,
                "WiFi,AC");
        assertTrue(trainDAO.addTrain(train));
        Train retrieved = trainDAO.getTrainByNumber("T100");
        assertNotNull(retrieved);
        assertEquals("Express A", retrieved.getTrainName());
    }

    @Test
    public void testUpdateTrain() throws Exception {
        Train train = new Train("T101", "Express B", "Express", "City A", "City C", "10:00", "14:00", 110.0, 4, 600.0,
                "WiFi");
        trainDAO.addTrain(train);
        train.setTrainName("Super Express B");
        train.setFare(700.0);
        assertTrue(trainDAO.updateTrain(train));
        Train updated = trainDAO.getTrainByNumber("T101");
        assertEquals("Super Express B", updated.getTrainName());
        assertEquals(700.0, updated.getFare());
    }

    @Test
    public void testDeleteTrain() throws Exception {
        Train train = new Train("T102", "Express C", "Mail", "City D", "City E", "11:00", "15:00", 100.0, 3, 400.0,
                "None");
        trainDAO.addTrain(train);
        assertTrue(trainDAO.deleteTrain("T102"));
        assertNull(trainDAO.getTrainByNumber("T102"));
    }

    @Test
    public void testSearchTrains() throws Exception {
        trainDAO.addTrain(new Train("T103", "Search Express", "Express", "City X", "City Y", "12:00", "16:00", 90.0, 4,
                300.0, "AC"));
        List<Train> results = TrainDAO.searchTrains("City X", "City Y");
        assertEquals(1, results.size());
    }

    @Test
    public void testSearchTrainsByPrefix() throws Exception {
        trainDAO.addTrain(
                new Train("T104", "Metro Line", "Metro", "City Z", "City W", "08:00", "10:00", 80.0, 2, 250.0, "None"));
        List<Train> results = trainDAO.searchTrainsByPrefix("Metro");
        assertEquals(1, results.size());
        assertEquals("Metro Line", results.get(0).getTrainName());
    }

    @Test
    public void testAllTrains() throws Exception {
        trainDAO.addTrain(new Train("T105", "Local Train", "Local", "Station A", "Station B", "07:00", "09:00", 60.0, 6,
                100.0, "None"));
        List<Train> all = trainDAO.allTrains();
        assertEquals(1, all.size());
    }
}