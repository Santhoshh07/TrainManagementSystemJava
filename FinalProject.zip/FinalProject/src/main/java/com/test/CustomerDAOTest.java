package com.test;

import com.bean.Customer;
import com.dao.CustomerDAO;
import com.helper.Helper;
import org.junit.jupiter.api.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerDAOTest {
    private static CustomerDAO customerDAO;

    @BeforeAll
    public static void setupDatabase() throws Exception {
        customerDAO = new CustomerDAO();
       
    }

    @BeforeEach
    public void cleanDatabase() throws Exception {
        try (Connection conn = Helper.CreateConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM customers");
        }
    }

    @Test
    public void testAddCustomer() throws Exception {
        Customer customer = new Customer("C001", "John Doe", "john@example.com", "123 Street", "1234567890", "pass123");
        assertTrue(customerDAO.addCustomer(customer));
    }

    @Test
    public void testGetCustomerByEmail() throws Exception {
        Customer customer = new Customer("C002", "Jane Smith", "jane@example.com", "456 Avenue", "9876543210",
                "pass456");
        customerDAO.addCustomer(customer);
        Customer retrieved = customerDAO.getCustomerByEmail("jane@example.com");
        assertNotNull(retrieved);
        assertEquals("Jane Smith", retrieved.getCustomerName());
    }

    @Test
    public void testUpdateCustomer() throws Exception {
        Customer customer = new Customer("C003", "Mark Taylor", "mark@example.com", "789 Road", "5551234567",
                "oldpass");
        customerDAO.addCustomer(customer);
        Customer updated = new Customer("C003", "Mark T.", "mark@example.com", "Updated Road", "5557654321", "newpass");
        assertTrue(customerDAO.updateCustomer(updated));
        Customer retrieved = customerDAO.getCustomerByEmail("mark@example.com");
        assertEquals("Mark T.", retrieved.getCustomerName());
        assertEquals("Updated Road", retrieved.getAddress());
        assertEquals("newpass", retrieved.getPassword());
    }

    @Test
    public void testDeleteCustomer() throws Exception {
        Customer customer = new Customer("C004", "Anna Bell", "anna@example.com", "Main Street", "4445556666",
                "annapass");
        customerDAO.addCustomer(customer);
        assertTrue(customerDAO.deleteCustomer("anna@example.com"));
        assertNull(customerDAO.getCustomerByEmail("anna@example.com"));
    }

  
    @Test
    public void testGetAllCustomers() throws Exception {
        customerDAO.addCustomer(
                new Customer("C006", "Alice", "alice@example.com", "Green Street", "7778889999", "alicepass"));
        customerDAO.addCustomer(new Customer("C007", "Bob", "bob@example.com", "Blue Avenue", "1112223333", "bobpass"));
        List<Customer> customers = customerDAO.getAllCustomers();
        assertEquals(2, customers.size());
    }
}